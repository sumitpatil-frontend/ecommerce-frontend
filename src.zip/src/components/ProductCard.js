import { Card, CardContent, CardActions, Typography, Button, CardMedia } from "@mui/material";
import { styled } from "@mui/system";

// Hover zoom effect
const ZoomCardMedia = styled(CardMedia)({
  transition: "transform 0.3s",
  "&:hover": {
    transform: "scale(1.1)",
  },
});

export default function ProductCard({ product, addToCart }) {
  return (
    <Card sx={{ maxWidth: 250, margin: 2 }}>
      <ZoomCardMedia
        component="img"
        height="140"
        image={product.image}
        alt={product.name}
      />
      <CardContent>
        <Typography gutterBottom variant="h6">{product.name}</Typography>
        <Typography variant="body1">₹{product.price}</Typography>
      </CardContent>
      <CardActions>
        <Button size="small" variant="contained" onClick={() => addToCart(product)}>Add to Cart</Button>
      </CardActions>
    </Card>
  );
}

import { Container, Typography } from "@mui/material";

export default function Home() {
  return (
    <Container sx={{ paddingY: 4 }}>
      <Typography variant="h3" gutterBottom>Welcome to MyShop!</Typography>
      <Typography>Your one-stop shop for amazing products.</Typography>
    </Container>
  );
}

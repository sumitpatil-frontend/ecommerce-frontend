import { useContext, useState } from "react";
import { CartContext } from "../context/CartContext";
import { Container, Typography, Button, Box } from "@mui/material";

export default function Checkout() {
  const { cart, removeFromCart, clearCart } = useContext(CartContext);
  const [showQR, setShowQR] = useState(false);
  const [paymentDone, setPaymentDone] = useState(false);

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const handlePayNow = () => setShowQR(true);
  const handleConfirmPayment = () => {
    setPaymentDone(true);
    clearCart();
    setShowQR(false);
  };

  return (
    <Container sx={{ paddingY: 4 }}>
      <Typography variant="h4" gutterBottom>Checkout</Typography>

      {cart.length === 0 && !paymentDone && (
        <Typography>Your cart is empty.</Typography>
      )}

      {paymentDone && (
        <Typography color="success.main" variant="h6">
          Payment Successful! Thank you for shopping 😊
        </Typography>
      )}

      {cart.length > 0 && !paymentDone && (
        <Box>
          {cart.map((item, index) => (
            <Box key={index} sx={{ display: "flex", justifyContent: "space-between", marginY: 1 }}>
              <Typography>{item.name} - ₹{item.price}</Typography>
              <Button color="error" onClick={() => removeFromCart(index)}>Remove</Button>
            </Box>
          ))}

          <Typography variant="h6" sx={{ marginY: 2 }}>Total: ₹{total}</Typography>

          <Box sx={{ marginY: 2 }}>
            <Button 
              variant="contained" 
              color="primary" 
              onClick={handlePayNow} 
              sx={{ marginRight: 2 }}
            >
              Pay Now
            </Button>
            <Button 
              variant="outlined" 
              color="error" 
              onClick={clearCart}
            >
              Clear Cart
            </Button>
          </Box>

          {showQR && (
            <Box sx={{ marginTop: 4, textAlign: "center" }}>
              <img 
                src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=DummyPayment" 
                alt="QR Code"
              />
              <Typography sx={{ marginTop: 1 }}>Scan this QR code to pay ₹{total}</Typography>
              <Button 
                variant="contained" 
                color="success" 
                sx={{ marginTop: 2 }} 
                onClick={handleConfirmPayment}
              >
                Confirm Payment
              </Button>
            </Box>
          )}
        </Box>
      )}
    </Container>
  );
}

import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import ProductCard from "../components/ProductCard";
import { Grid, Container, Typography } from "@mui/material";

// Import local images (rename files to kebab-case)
import RedTshirt from "../assets/red-tshirt.jpg";
import BlueJeans from "../assets/blue-jeans.jpg";
import WhiteHoodie from "../assets/white-hoodie.jpg";
import BlackJacket from "../assets/black-jacket.jpg";
import GreenTshirt from "../assets/green-tshirt.jpg";
import BrownBoots from "../assets/brown-boots.jpg";

const clothingProducts = [
  { id: 1, name: "Red T-Shirt", price: 499, image: RedTshirt },
  { id: 2, name: "Blue Jeans", price: 899, image: BlueJeans },
  { id: 3, name: "White Hoodie", price: 1299, image: WhiteHoodie },
  { id: 4, name: "Black Jacket", price: 1999, image: BlackJacket },
  { id: 5, name: "Green T-Shirt", price: 549, image: GreenTshirt },
  { id: 6, name: "Brown Boots", price: 2599, image: BrownBoots },
];

export default function Products() {
  const { addToCart } = useContext(CartContext);

  return (
    <Container sx={{ paddingY: 4 }}>
      <Typography variant="h4" gutterBottom>Clothing Shop</Typography>
      <Grid container spacing={2}>
        {clothingProducts.map((p) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={p.id}>
            <ProductCard product={p} addToCart={addToCart} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
